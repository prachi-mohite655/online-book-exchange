const items = document.getElementById("items");

const additems = () => {
  let auth = localStorage.getItem("cart");
  let num = getRandomInt(1, 4);
  let price = getRandomInt(10, 100);
  const imgs = ["economic.jpg", "freefall.jpg", "darknet.jpg", "lloyd.jpg"];

  const obj = {
    name: `product ${num}`,
    price,
    itemNum: items.value,
    img: imgs[num - 1],
  };
  if (auth) {
    let items = JSON.parse(auth);
    let arr = [...items, obj];
    localStorage.removeItem("cart");
    localStorage.setItem("cart", JSON.stringify(arr));
  } else {
    localStorage.setItem("cart", JSON.stringify([obj]));
  }
};

function getRandomInt(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min + 1)) + min;
}


// Get the button and container
const addProductBtn = document.getElementById('addProductBtn');
const boxContainer = document.getElementById('productbox');

// Function to add a product dynamically
function addNewProduct() {
   // Prompt the user for product details
   const productName = prompt("Enter the product name:");
   const productPrice = prompt("Enter the product price:");
   const productImage = prompt("Enter the product image URL:");

   // Validate inputs
   if (!productName || !productPrice || !productImage) {
      alert("All fields are required!");
      return;
   }

   // Create a new product box
   const newProduct = document.createElement('div');
   newProduct.classList.add('box');

   // Set the inner HTML for the new product
   newProduct.innerHTML = `
      <img class="image ximage" src="${productImage}" alt="Product Image">
      <div class="name">${productName}</div>
      <div class="price">$${parseFloat(productPrice).toFixed(2)}/-</div>
      <input type="number" min="1" name="product_quantity" value="1" class="qty">
      <input type="hidden" name="product_name" value="${productName}">
      <input type="hidden" name="product_price" value="${parseFloat(productPrice).toFixed(2)}">
      <input type="hidden" name="product_image" value="${productImage}">
      <button onclick="additems()" class="btn">Add to Cart</button>
   `;

   // Append the new product to the container
   boxContainer.appendChild(newProduct);
}

// Attach event listener to the button
addProductBtn.addEventListener('click', addNewProduct);

