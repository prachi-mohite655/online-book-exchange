const cart = document.getElementById("cart");
const total = document.getElementById("total");

let auth = localStorage.getItem("cart");
let price = 0;
if (auth) {
  let items = JSON.parse(auth);
  let text = items
    .map((e, i) => {
      return `<div class="box">
         <img src="images/${e.img}" alt="Product Image">
         <div class="name">${e.name}</div>
         <div class="price">$${e.price}.00/-</div>
         <input type="number" min="1" value="${e.itemNum}" class="qty">
         <button onclick="remove(${i})" class="btn">Remove</button>
      </div>`;
    })
    .join(" ");
  cart.innerHTML = text;
  items.forEach((e) => {
    price += e.price * e.itemNum;
  });
  total.innerHTML = `<h3>Total: ${price}.00</h3>
      <button onclick='buy()' class="btn">Proceed to Checkout</button>`;
} else {
  cart.innerHTML =
    "<h1 style='text-align: center; font-size: 2rem; color: red; padding: 2rem;'> No items in your cart </h1>";
  total.innerHTML = "";
}

const remove = (ind) => {
  let items = JSON.parse(auth);
  let arr = items.filter((e, i) => i !== ind);
  localStorage.removeItem("cart");
  if (arr.length) {
    localStorage.setItem("cart", JSON.stringify(arr));
  }
  window.location.reload();
};

const buy = async () => {
  const amountInPaise = price * 100;

  try {
    let amount = price;
    const data = await fetch("http://localhost:8000/order", {
      method: "POST",
      body: JSON.stringify({ amount }),
      headers: { "Content-Type": "application/json" },
    });
    const res = await data.json();
    const order = res.order;

    // Initialize Razorpay checkout
    const razorpayOptions = {
      key: "rzp_test_PIRuecVMTUthfb", // Your Razorpay Key ID
      amount: Number(order.amount),
      currency: "INR",
      name: "GameZone Admin",
      description: "Here to Give You a Safe Platform to Game",
      image:
        "https://previews.123rf.com/images/mariusz_prusaczyk/mariusz_prusaczyk1212/mariusz_prusaczyk121200626/17047839-3d-word-game-on-white-background.jpg",
      order_id: order.id, //This is a sample Order ID. Pass the `id` obtained in the response of Step 1
      //   callback_url: `/home.html`,
      prefill: {
        name: "Gaurav Kumar",
        email: "gaurav.kumar@example.com",
        contact: "9000090000",
      },
      notes: {
        address: "Razorpay Corporate Office",
      },
      theme: {
        color: "#3399cc",
      },
    };

    const razor = new window.Razorpay(razorpayOptions);
    await razor.open();
    localStorage.removeItem("cart");
    let ord = localStorage.getItem("order");
    if (ord) {
      let arr = JSON.parse(ord);
      localStorage.removeItem("order");
      localStorage.setItem("order", JSON.stringify([...arr, [price, 1]]));
    } else {
      localStorage.setItem("order", JSON.stringify([[price, 0]]));
    }
  } catch (error) {
    console.error("Error:", error);
    alert("Something went wrong while creating the order.");
  }
};
