const express = require("express");
const app = express();
const cors = require("cors");

const Razorpay = require("razorpay");
const instance = new Razorpay({
  key_id: "rzp_test_PIRuecVMTUthfb",
  key_secret: "DtPx36zTtCYCUz18JMXYQqAr",
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors());

app.post("/order", async (req, res) => {
  const { amount } = req.body;

  const options = {
    amount: Number(amount) * 100, // amount in the smallest currency unit
    currency: "INR",
    receipt: "order_rcptid_11",
  };
  const order = await instance.orders.create(options);

  res.json({
    success: true,
    order,
  });
});

app.listen(8000);
