let ord = document.getElementById("orders");

let auth = localStorage.getItem("order");
if (auth) {
  let items = JSON.parse(auth);
  let text = items
    .map((e, i) => {
      return `<div class="box">
         <p>Name: <span>John Doe</span></p>
         <p>Number: <span>+1234567890</span></p>
         <p>Email: <span>johndoe@example.com</span></p>
         <p>Address: <span>123 Main St, Anytown, USA</span></p>
         <p>Payment method: <span>Credit Card</span></p>
         <p>Your orders: <span>Product 1, Product 2</span></p>
         <p>Total price: <span>$${e[0]}.00/-</span></p>
         <p>Payment status: <span style="color:green;">${
           e[1] == 0 ? "running" : e[1] == 1 ? "delivered" : "exchange running"
         }</span></p>
         ${
           e[1] == 1
             ? `<button class='btn' onclick=exchange(${i})> return </button>`
             : `<button class='btn' onclick='deliver(${i})'> deliver </button>`
         }
      </div>`;
    })
    .join(" ");
  ord.innerHTML = text;
} else {
  ord.innerHTML =
    "<h1 style='text-align: center; font-size: 2rem; color: red; padding: 2rem;'> No orders yet </h1>";
}

const remove = (ind) => {
  let items = JSON.parse(auth);
  let arr = items.filter((e, i) => i !== ind);
  localStorage.removeItem("cart");
  if (arr.length) {
    localStorage.setItem("cart", JSON.stringify(arr));
  }
  window.location.reload();
};

const deliver = (index) => {
  let auth = localStorage.getItem("order");
  let data = JSON.parse(auth);
  let arr = data.map((e, i) => {
    if (i == index) {
      return [e[0], 1];
    }
    return e;
  });
  localStorage.removeItem("order");
  localStorage.setItem("order", JSON.stringify(arr));
  window.location.reload();
};

const exchange = (index) => {
  let auth = localStorage.getItem("order");
  let data = JSON.parse(auth);
  let arr = data.map((e, i) => {
    if (i == index) {
      return [e[0], 2];
    }
    return e;
  });
  localStorage.removeItem("order");
  localStorage.setItem("order", JSON.stringify(arr));
  window.location.reload();
};
